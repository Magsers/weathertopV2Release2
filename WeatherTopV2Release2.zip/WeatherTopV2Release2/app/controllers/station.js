"use strict";

const logger = require("../utils/logger");
const stationList = require("../models/station-list");
const uuid = require("uuid");
const stationAnalytics = require("../utils/station-analytics");

const station = {
  index(request, response) {
    const stationId = request.params.id;

    let latestReading = null;
    let weatherCode = null;
    let iconClass = null;
    let fahrenheit = null;
    let beaufort = null;
    let windDirection = null;
    let windChill = null;
    let minTemp = null;
    let maxTemp = null;
    let minWind = null;
    let maxWind = null;
    let minPressure = null;
    let maxPressure = null;
    
    const station = stationList.getStation(stationId);
    if (station.readings.length > 0) {
      latestReading = station.readings[station.readings.length - 1];
      weatherCode = stationAnalytics.codeToText(Number(latestReading.code));
      iconClass = stationAnalytics.weatherIcon(Number(latestReading.code));
      fahrenheit = stationAnalytics.fahrenheit(Number(latestReading.temp));
      beaufort = stationAnalytics.beaufort(Number(latestReading.windSpeed));
      windDirection = stationAnalytics.windCompass(Number(latestReading.windDirection));
      windChill = stationAnalytics.windChillCalc(latestReading.temp, fahrenheit);
      minTemp = stationAnalytics.getMinTemp(station);
      maxTemp = stationAnalytics.getMaxTemp(station);
      minWind = stationAnalytics.getMinWind(station);
      maxWind = stationAnalytics.getMaxWind(station);
      minPressure = stationAnalytics.getMinPressure(station);
      maxPressure = stationAnalytics.getMaxPressure(station);
    }
    logger.debug("Station id = ", stationId);
    console.log("MinTemp : " + minWind+ " " + maxWind); 
     
    const viewData = {
      title: "Station",
      station: stationList.getStation(stationId),
      latestReading: latestReading,
      weatherCode: weatherCode,
      iconClass : iconClass,
      fahrenheit : fahrenheit,
      beaufort : beaufort,
      windDirection : windDirection,
      windChill : windChill,
      minTemp : minTemp,
      maxTemp : maxTemp,
      minWind : minWind,
      maxWind : maxWind,
      minPressure : minPressure,
      maxPressure : maxPressure
    };
    response.render("station", viewData);
  },

  deleteReading(request, response) {
    const stationId = request.params.id;
    const readingId = request.params.readingId;
    logger.debug(`Deleting Reading ${readingId} from Station ${stationId}`);
    stationList.removeReading(stationId, readingId);
    response.redirect("/station/" + stationId);
  },

  addReading(request, response) {
    const stationId = request.params.id;
    const station = stationList.getStation(stationId);
    const newReading = {
      id: uuid.v1(),
      code: request.body.code,
      temp: request.body.temp,
      windSpeed: request.body.windSpeed,
      windDirection: request.body.windDirection,
      pressure: request.body.pressure
    };
    logger.debug("New Reading = ", newReading);
    stationList.addReading(stationId, newReading);
    response.redirect("/station/" + stationId);
  },

  codeToText(code) {
     switch (code) {
      case 100:
        return "Clear";
      case 200:
        return "Partial Clouds";
      case 300:
        return "Cloudy";
      case 400:
        return "Light Showers";
      case 500:
        return "Heavy Showers";
      case 600:
        return "Rain";
      case 700:
        return "Snow";
      case 800:
        return "Thunder";
      default:
        return "error";
    }
  },
  
      
      calculations(request, response){
        const latestReading = null;
        const stationId = request.params.id;
        const station = stationList.getStation(stationId);
        if(station.readings.size() > 0 ) {
          latestReading = station.readings.get(station.readings.size() - 1);
          station.weathercode = stationAnalytics.codeToText(latestReading.code);
        }
        return latestReading;
      },
};

module.exports = station;
