WeatherTop Version 2 ICT Skills Release 1
==============================

Student Name : Margaret McCarthy
Student Nubmer : 20095610
WIT HDip in Computer Science 2021


This is the Baseline version for WeatherTop Version 2 for ICT Skills for WIT HDip in Computer Science.  

Reading : Code, Temp, Wind Speed and Pressure + Wind Direction

Station : Station Name, Latest Weather Report, Temperature in C and F, Wind in Bft and Pressure + Wind Chill, Wind Compass

Member : None

Features : Dashboard shows station list + button to open station view. Include forms to add new Station + new reading.


